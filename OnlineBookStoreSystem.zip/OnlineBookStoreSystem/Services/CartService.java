package Services;
import Models.Book;
import Datastructures.Stack.CartStack;

public class CartService {
    private CartStack historyStack;

    public CartService(int maxHistorySize) {
        this.historyStack = new CartStack(maxHistorySize);
    }

    // Customer adds a book to their cart (Stack Push)
    public void addProductToCart(Book book) {
        historyStack.push(book);
        System.out.println("[Cart] Added to cart: " + book.getTitle());
    }

    // Customer presses Undo — removes the most recently added book (Stack Pop)
    public void undoLastAction() {
        Book removedBook = historyStack.pop();
        if (removedBook != null) {
            System.out.println("[Cart] UNDO: Removed '" + removedBook.getTitle() + "' from cart.");
        }
    }

    // View all books currently in the cart
    public void viewCart() {
        System.out.println("\n=== YOUR SHOPPING CART ===");
        historyStack.displayCart();
        System.out.println("=========================");
    }

    // Checkout: extract all books from the cart (empties the cart)
    public Book[] checkoutCart() {
        return historyStack.checkoutAll();
    }
}
