package Services;
import Models.Book;
import Models.Order;
import Datastructures.Sorting.BookSorter;

public class CatalogService {

    // Display the list of books in an order, sorted alphabetically by title
    public void displaySortedBooksInOrder(Order order) {
        System.out.println("\n--- Book Details for Order: " + order.getOrderId() + " ---");
        System.out.println("Customer: " + order.getCustomerName());
        System.out.println("Status:   " + order.getStatus());

        Book[] books = order.getBooks();
        int count = order.getBookCount();

        if (count == 0) {
            System.out.println("This order contains no books.");
            return;
        }

        // Call Merge Sort algorithm 
        BookSorter.sortBooksByTitle(books, count);

        // Print the sorted list
        System.out.println("\nBooks (sorted by title A-Z):");
        for (int i = 0; i < count; i++) {
            System.out.printf("  %d. %s | Author: %s | Qty: %d%n",
                    (i + 1), books[i].getTitle(), books[i].getAuthor(), books[i].getQuantity());
        }
        System.out.println("------------------------------------------");
    }
}
