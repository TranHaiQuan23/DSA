package Services;
import Models.Order;
import Datastructures.Queue.OrderQueue;

public class OrderService {
    private OrderQueue pendingQueue;
    private OrderQueue processingQueue;

    public OrderService() {
        this.pendingQueue = new OrderQueue();
        this.processingQueue = new OrderQueue();
    }

    // ==================== CUSTOMER ACTION ====================


    public void placeOrder(Order order) {
        order.setStatus("Pending");
        pendingQueue.enqueue(order);
        System.out.println("[Order Service] Received order " + order.getOrderId()
                + " from " + order.getCustomerName() + ". Status: Pending");
    }

    // ==================== ADMIN ACTIONS ====================

    public Order approveNextOrder() {
        if (pendingQueue.isEmpty()) {
            System.out.println("[Order Service] No pending orders to approve.");
            return null;
        }

        
        Order order = pendingQueue.dequeue();
        order.setStatus("Processing");

       
        processingQueue.enqueue(order);
        System.out.println("[Order Service] APPROVED order " + order.getOrderId()
                + " -> Status: Processing (packing in progress)");
        return order;
    }

    
    public Order shipNextOrder() {
        if (processingQueue.isEmpty()) {
            System.out.println("[Order Service] No orders in Processing to ship.");
            return null;
        }

     
        Order order = processingQueue.dequeue();
        order.setStatus("Shipped");
        System.out.println("[Order Service] SHIPPED order " + order.getOrderId()
                + " -> Status: Shipped (on the way to customer)");
        return order;
    }

    // ==================== PEEK & STATUS ====================

    // Peek at the next order in line (without removing) for each queue
    public Order peekPending()    { return pendingQueue.peek(); }
    public Order peekProcessing() { return processingQueue.peek(); }

    // Check if queues have orders
    public boolean hasPendingOrders()    { return !pendingQueue.isEmpty(); }
    public boolean hasProcessingOrders() { return !processingQueue.isEmpty(); }

    // Get the count of orders in each queue
    public int getPendingCount()    { return pendingQueue.getSize(); }
    public int getProcessingCount() { return processingQueue.getSize(); }
}
