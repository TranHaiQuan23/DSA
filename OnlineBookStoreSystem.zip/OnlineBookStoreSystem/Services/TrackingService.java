package Services;
import Models.Order;
import Datastructures.Searching.OrderSearcher;

public class TrackingService {

//Binary Search

    public void trackOrderStatus(Order[] systemOrders, int orderCount, String orderId) {
        System.out.println("\n[Tracking Service] Searching for order: " + orderId + "...");

        // Call Binary Search algorithm — O(log n) time complexity
        Order foundOrder = OrderSearcher.binarySearchByOrderId(systemOrders, orderCount, orderId);

        if (foundOrder != null) {
            System.out.println("  Order found!");
            System.out.println("  - Order ID:         " + foundOrder.getOrderId());
            System.out.println("  - Customer:         " + foundOrder.getCustomerName());
            System.out.println("  - Current Status:   " + foundOrder.getStatus());
            System.out.println("  - Shipping Address: " + foundOrder.getShippingAddress());
            System.out.println("  - Books in order:   " + foundOrder.getBookCount());
        } else {
            System.out.println("  Order not found with ID: " + orderId);
        }
    }
}
