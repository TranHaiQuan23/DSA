package Models;

public class Book {
    private String bookId;
    private String title;
    private String author;
    private double price;
    private int quantity;

    // Constructor to initialize a book
    public Book(String bookId, String title, String author, double price, int quantity) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.price = price;
        this.quantity = quantity;
    }

    // --- Getters and Setters ---
    public String getBookId() { return bookId; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public double getPrice() { return price; }
    public int getQuantity() { return quantity; }

    public void setPrice(double price) { this.price = price; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    @Override
    public String toString() {
        // Dùng String.format để căn lề và định dạng số thập phân (%.2f) cho giá tiền rất đẹp
        return String.format("Book[ID=%s, Title='%s', Author='%s', Price=%.2f VND, Qty=%d]",
                             bookId, title, author, price, quantity);
    }
}