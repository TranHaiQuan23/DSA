package Models;

public class Order {
    private String orderId;
    private String customerName;
    private String shippingAddress;
    private Book[] books;       // Fixed-size array to apply Sorting algorithms
    private int bookCount;      // Actual number of books in the array
    private String status;      // Status: "Pending", "Processing", "Shipped"

    // Constructor
    public Order(String orderId, String customerName, String shippingAddress, int maxBooks) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.shippingAddress = shippingAddress;
        this.books = new Book[maxBooks];
        this.bookCount = 0;
        this.status = "Pending";
    }

    // Add a book to the order
    public void addBook(Book book) {
        if (bookCount < books.length) {
            books[bookCount] = book;
            bookCount++;
        } else {
            System.out.println("Error: Order has reached the maximum number of books!");
        }
    }

    // Getters 
    public String getOrderId() { return orderId; }
    public String getCustomerName() { return customerName; }
    public String getShippingAddress() { return shippingAddress; }
    public Book[] getBooks() { return books; }
    public int getBookCount() { return bookCount; }
    public String getStatus() { return status; }

    // Setters 
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return String.format("Order[ID=%s, Customer='%s', Status='%s', Books=%d]",
                             orderId, customerName, status, bookCount);
    }
}
