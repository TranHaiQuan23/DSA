package Datastructures.Stack;
import Models.Book;

public class StackNode {
    public Book book;
    public StackNode next;

    public StackNode(Book book) {
        this.book = book;
        this.next = null;
    }
}