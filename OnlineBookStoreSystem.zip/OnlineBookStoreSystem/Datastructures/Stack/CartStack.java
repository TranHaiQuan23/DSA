package Datastructures.Stack;
import Models.Book;

public class CartStack {
    private StackNode top; 
    private int maxSize;
    private int currentSize;

    // Stack
    public CartStack(int size) {
        this.maxSize = size;
        this.top = null;
        this.currentSize = 0;
    }

    // 1. Push
    public void push(Book book) {
        if (isFull()) {
            System.out.println("Stack Overflow: Cart is full, cannot add more books.");
            return;
        }
        StackNode newNode = new StackNode(book);
        newNode.next = top; 
        top = newNode;      
        currentSize++;
    }

    // 2. Pop (O(1))
    public Book pop() {
        if (isEmpty()) {
            System.out.println("Stack Underflow: Cart is empty, nothing to undo.");
            return null;
        }
        Book poppedBook = top.book; 
        top = top.next;             
        currentSize--;
        return poppedBook;
    }

    // 3. Peek (O(1))
    public Book peek() {
        if (isEmpty()) return null;
        return top.book;
    }

    public boolean isEmpty() { return top == null; }
    public boolean isFull()  { return currentSize >= maxSize; }


    public void displayCart() {
        if (isEmpty()) {
            System.out.println("  Your cart is empty.");
            return;
        }
        StackNode current = top;
        while (current != null) {
            System.out.println("  - " + current.book.getTitle() + " (ID: " + current.book.getBookId() + ")");
            current = current.next;
        }
    }


    public Book[] checkoutAll() {
        if (isEmpty()) return new Book[0];
        
        Book[] items = new Book[currentSize];
        int originalSize = currentSize;
        

        for (int i = 0; i < originalSize; i++) {
            items[i] = pop();
        }
        return items; 
    }
}