package Datastructures.Queue;
import Models.Order;

public class OrderQueue {
    private QueueNode front; // Head of the queue (oldest order, ready to be processed)
    private QueueNode rear;  // Tail of the queue (newest order, just added)
    private int size;

    public OrderQueue() {
        this.front = this.rear = null;
        this.size = 0;
    }

    // Operation 1: Enqueue - Add a new order to the rear of the queue
    public void enqueue(Order newOrder) {
        QueueNode newNode = new QueueNode(newOrder);

        // If the queue is empty, the new node becomes both front and rear
        if (this.rear == null) {
            this.front = this.rear = newNode;
            size++;
            return;
        }

        // Otherwise, link the new node after the current rear, then move rear
        this.rear.next = newNode;
        this.rear = newNode;
        size++;
    }

    // Operation 2: Dequeue - Remove and return the order at the front
    public Order dequeue() {
        if (this.front == null) {
            System.out.println("Queue is empty, no orders to process!");
            return null;
        }

        // Save the front node to return later
        QueueNode temp = this.front;

        // Move front to the next node in line
        this.front = this.front.next;

        // If the queue becomes empty after removal, reset rear to null as well
        if (this.front == null) {
            this.rear = null;
        }
        size--;
        return temp.order;
    }

    // Operation 3: Peek - View the front order without removing it
    public Order peek() {
        if (this.front == null) {
            return null;
        }
        return this.front.order;
    }

    public boolean isEmpty() {
        return front == null;
    }

    public int getSize() {
        return size;
    }
}
