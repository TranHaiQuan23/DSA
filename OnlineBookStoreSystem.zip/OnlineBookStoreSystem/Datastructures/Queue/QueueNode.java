package Datastructures.Queue;
import Models.Order;

public class QueueNode {
    Order order;       // Data stored in this node (an Order object)
    QueueNode next;    // Pointer to the next node in the queue

    public QueueNode(Order order) {
        this.order = order;
        this.next = null;
    }
}
