package Datastructures.Searching;
import Models.Order;

public class OrderSearcher {

   
    public static Order binarySearchByOrderId(Order[] orders, int length, String targetOrderId) {
        int left = 0;
        int right = length - 1;

        while (left <= right) {
            // Find the middle index
            int mid = left + (right - left) / 2;

            // Compare the orderId at position mid with the target
            int comparisonResult = orders[mid].getOrderId().compareToIgnoreCase(targetOrderId);

            if (comparisonResult == 0) {
                // Exact match found, return this order
                return orders[mid];
            }
            else if (comparisonResult < 0) {
                // orderId at mid is smaller than target, so target is in the right half
                left = mid + 1;
            }
            else {
                // orderId at mid is larger than target, so target is in the left half
                right = mid - 1;
            }
        }

    
        return null;
    }
}
