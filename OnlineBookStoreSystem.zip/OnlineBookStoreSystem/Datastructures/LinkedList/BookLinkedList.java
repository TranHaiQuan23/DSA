package Datastructures.LinkedList;
import Models.Book;

public class BookLinkedList {
    private BookNode head;
    private int size;

    public BookLinkedList() {
        this.head = null;
        this.size = 0;
    }

    // Add book into the list
    public void add(Book book) {
        BookNode newNode = new BookNode(book);
        if (head == null) {
            head = newNode;
        } else {
            BookNode current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
        size++;
    }

    // Finding books (Linear Search O(n))
    public Book findById(String bookId) {
        BookNode current = head;
        while (current != null) {
            if (current.book.getBookId().equalsIgnoreCase(bookId)) {
                return current.book;
            }
            current = current.next;
        }
        return null;
    }

    // Display all book in inventory
    public void displayAll() {
        BookNode current = head;
        while (current != null) {
            System.out.println(current.book.toString());
            current = current.next;
        }
    }

    // Sum of books
    public int getTotalBooks() {
        int total = 0;
        BookNode current = head;
        while (current != null) {
            total += current.book.getQuantity();
            current = current.next;
        }
        return total;
    }

    public int getSize() { return size; }

    //(Delete) 
    public boolean remove(String bookId) {
        if (head == null) {
            return false; 
        }
        
        if (head.book.getBookId().equalsIgnoreCase(bookId)) {
            head = head.next; 
            size--;
            return true;
        }
    
        BookNode current = head;
        BookNode previous = null;

        while (current != null && !current.book.getBookId().equalsIgnoreCase(bookId)) {
            previous = current;     
            current = current.next;  
        }
       
        if (current == null) {
            return false; 
        }

        previous.next = current.next; 
        size--;
        return true;
    }
}