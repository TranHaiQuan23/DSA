import Models.Book;
import Models.Order;
import Services.CartService;
import Services.CatalogService;
import Services.OrderService;
import Services.TrackingService;
import Datastructures.LinkedList.BookLinkedList;
import java.util.Scanner;

public class MainApplication {
    // ==================== MOCK DATABASE ====================
    static BookLinkedList bookCatalog = new BookLinkedList();
    static Order[] databaseOrders = new Order[100];
    static int globalOrderCount = 0;
    static int orderIdCounter = 1;

    // ==================== SERVICES ====================
    static CartService cartService = new CartService(20);
    static OrderService orderService = new OrderService();
    static CatalogService catalogService = new CatalogService();
    static TrackingService trackingService = new TrackingService();

    // ==================== MAIN ====================
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        loadSampleData();

        int choice = -1;
        while (choice != 0) {
            System.out.println("\n============================================");
            System.out.println("          ONLINE BOOKSTORE SYSTEM");
            System.out.println("============================================");
            System.out.println("  1. Login as CUSTOMER");
            System.out.println("  2. Login as ADMIN (Staff)");
            System.out.println("  0. Exit System");
            System.out.print("Please select an option (0-2): ");

            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (Exception e) {
                choice = -1;
            }

            if (choice == 1) {
                customerMenu(scanner);
            } else if (choice == 2) {
                adminMenu(scanner);
            } else if (choice == 0) {
                System.out.println("Thank you for using our system. Goodbye!");
            } else {
                System.out.println("Invalid choice! Please try again.");
            }
        }
        scanner.close();
    }

    // ==================== CUSTOMER FLOW ====================
    private static void customerMenu(Scanner scanner) {
        System.out.print("\nEnter your name to start shopping: ");
        String customerName = scanner.nextLine();
        int choice = -1;

        while (choice != 0) {
            System.out.println("\n--- HELLO CUSTOMER: " + customerName.toUpperCase() + " ---");
            System.out.println("1. View book catalog");
            System.out.println("2. Add a book to cart");
            System.out.println("3. View your cart");
            System.out.println("4. Undo (Remove the last added book from cart)");
            System.out.println("5. CHECKOUT & PLACE ORDER");
            System.out.println("6. Track order status (Binary Search)");
            System.out.println("0. Logout (Return to Main Menu)");
            System.out.print("Select a feature: ");

            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (Exception e) {
                System.out.println("Invalid input!");
                continue;
            }

            switch (choice) {
                case 1:
                    System.out.println("\n[OUR BOOK CATALOG]");
                    bookCatalog.displayAll();
                    break;
                case 2:
                    System.out.print("Enter the BOOK ID you want to buy (e.g., B01): ");
                    String bookId = scanner.nextLine();
                    Book foundBook = findBookInCatalog(bookId);
                    
                    if (foundBook != null) {
                        if (foundBook.getQuantity() > 0) {
                            cartService.addProductToCart(foundBook);
                            System.out.println("✅ Added '" + foundBook.getTitle() + "' to your cart!");
                        } else {
                            System.out.println("❌ Error: Sorry, this book is out of stock!");
                        }
                    } else {
                        System.out.println("❌ Error: Book with ID '" + bookId + "' not found in the system!");
                    }
                    break;
                case 3:
                    cartService.viewCart();
                    break;
                case 4:
                    cartService.undoLastAction();
                    break;
                case 5:
                    Book[] itemsToBuy = cartService.checkoutCart();
                    if (itemsToBuy.length == 0) {
                        System.out.println("⚠️ Your cart is empty! Please add something before checking out.");
                        break;
                    }

                    double totalPrice = 0;
                    System.out.println("\n--- CHECKOUT SUMMARY ---");
                    for (Book b : itemsToBuy) {
                        System.out.printf("- %s (%.2f VND)\n", b.getTitle(), b.getPrice());
                        totalPrice += b.getPrice();
                    }
                    System.out.printf("=> TOTAL AMOUNT TO PAY: %.2f VND\n", totalPrice);
                    System.out.println("------------------------");

                    System.out.print("Enter your shipping address: ");
                    String address = scanner.nextLine();

                    String newOrderId = String.format("ORD-%03d", orderIdCounter++);
                    Order newOrder = new Order(newOrderId, customerName, address, 20);

                    for (Book b : itemsToBuy) {
                        newOrder.addBook(b);
                        b.setQuantity(b.getQuantity() - 1); 
                    }

                    orderService.placeOrder(newOrder);
                    databaseOrders[globalOrderCount++] = newOrder;

                    System.out.println("✅ Order placed successfully! Your order ID is: " + newOrderId);
                    break;
                case 6:
                    System.out.print("Enter your order ID (e.g., ORD-001): ");
                    String searchId = scanner.nextLine();
                    trackingService.trackOrderStatus(databaseOrders, globalOrderCount, searchId);
                    break;
                case 0:
                    System.out.println("Logging out...");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    // ==================== ADMIN FLOW ====================
    private static void adminMenu(Scanner scanner) {
        System.out.print("\nEnter Admin password (Hint: admin): ");
        String pass = scanner.nextLine();
        if (!pass.equals("admin")) {
            System.out.println("❌ Incorrect password! Access denied.");
            return;
        }

        int choice = -1;
        while (choice != 0) {
            System.out.println("\n--- ADMIN DASHBOARD ---");
            System.out.println("1. Process the next pending order");
            System.out.println("2. Ship the next processing order");
            System.out.println("3. View book details of an order (Merge Sort)");
            System.out.println("4. View overall order system status");
            System.out.println("5. View inventory statistics");
            System.out.println("6. Add a new book to catalog");
            System.out.println("7. Delete a book from catalog");
            System.out.println("0. Logout");
            System.out.print("Select a feature: ");

            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (Exception e) {
                System.out.println("Invalid input!");
                continue;
            }

            switch (choice) {
                case 1:
                    orderService.approveNextOrder();
                    break;
                case 2:
                    orderService.shipNextOrder();
                    break;
                case 3:
                    System.out.print("Enter the Order ID to view details (e.g., ORD-001): ");
                    String viewId = scanner.nextLine();
                    Order orderToView = findOrderInDatabase(viewId);
                    if (orderToView != null) {
                        catalogService.displaySortedBooksInOrder(orderToView);
                    } else {
                        System.out.println("❌ Order not found!");
                    }
                    break;
                case 4:
                    System.out.println("\n[ALL ORDERS IN THE SYSTEM]");
                    int pending = orderService.getPendingCount();
                    int processing = orderService.getProcessingCount();
                    for (int i = 0; i < globalOrderCount; i++) {
                        Order o = databaseOrders[i];
                        System.out.printf("- ID: %s | Customer: %s | Status: %s | Books Qty: %d\n",
                                o.getOrderId(), o.getCustomerName(), o.getStatus(), o.getBookCount());
                    }
                    System.out.println("=> Total: " + globalOrderCount + " orders | Pending: " + pending + " | Processing: " + processing);
                    break;
                case 5:
                    System.out.println("\n[INVENTORY STATISTICS]");
                    bookCatalog.displayAll();
                    System.out.println("=> TOTAL UNIQUE TITLES: " + bookCatalog.getSize());
                    break;
                case 6:
                    System.out.println("\n[ADD NEW BOOK TO INVENTORY]");
                    System.out.print("Enter new Book ID (e.g., B05): ");
                    String newId = scanner.nextLine();

                    if (findBookInCatalog(newId) != null) {
                        System.out.println("❌ Error: Book ID '" + newId + "' already exists! Cannot add duplicate.");
                        break;
                    }

                    System.out.print("Enter Book Title: ");
                    String newTitle = scanner.nextLine();

                    System.out.print("Enter Author Name: ");
                    String newAuthor = scanner.nextLine();

                    System.out.print("Enter Price (VND): ");
                    double newPrice = 0;
                    try {
                        newPrice = Double.parseDouble(scanner.nextLine());
                        if (newPrice < 0) {
                            System.out.println("❌ Error: Price cannot be negative.");
                            break;
                        }
                    } catch (Exception e) {
                        System.out.println("❌ Error: Invalid price number.");
                        break;
                    }

                    System.out.print("Enter Quantity: ");
                    int newQty = 0;
                    try {
                        newQty = Integer.parseInt(scanner.nextLine());
                        if (newQty < 0) {
                            System.out.println("❌ Error: Quantity cannot be negative.");
                            break;
                        }
                    } catch (Exception e) {
                        System.out.println("❌ Error: Invalid quantity number.");
                        break;
                    }

                    Book newBook = new Book(newId, newTitle, newAuthor, newPrice, newQty);
                    bookCatalog.add(newBook);

                    System.out.println("✅ Success: Book '" + newTitle + "' has been added to the catalog!");
                    break;
                case 7:
                    System.out.println("\n[DELETE BOOK FROM INVENTORY]");
                    System.out.print("Enter Book ID to delete (e.g., B01): ");
                    String deleteId = scanner.nextLine();
                    boolean isDeleted = bookCatalog.remove(deleteId);

                    if (isDeleted) {
                        System.out.println("✅ Success: Book with ID '" + deleteId + "' has been completely removed from the catalog!");
                    } else {
                        System.out.println("❌ Error: Book with ID '" + deleteId + "' not found. Cannot delete.");
                    }
                    break;
                case 0:
                    System.out.println("Logging out of Admin account...");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    // ==================== HELPER METHODS ====================
    private static Book findBookInCatalog(String bookId) {
        return bookCatalog.findById(bookId);
    }

    private static Order findOrderInDatabase(String orderId) {
        for (int i = 0; i < globalOrderCount; i++) {
            if (databaseOrders[i].getOrderId().equalsIgnoreCase(orderId)) {
                return databaseOrders[i];
            }
        }
        return null;
    }

    private static void loadSampleData() {
        bookCatalog.add(new Book("B01", "Java Programming", "John Doe", 150000.0, 100));
        bookCatalog.add(new Book("B02", "Data Structures", "Jane Smith", 120000.0, 50));
        bookCatalog.add(new Book("B03", "Clean Code", "Robert C. Martin", 200000.0, 20));
        bookCatalog.add(new Book("B04", "Head First Design Patterns", "Eric Freeman", 180000.0, 30));
    }
}